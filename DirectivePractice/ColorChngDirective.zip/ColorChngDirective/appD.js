﻿var app = angular.module('myApp', []);
app.directive('changeColor', function () {
    return{
        restrict: 'EA',
        scope: {
            colour:'=',
            func:'&'
        },
        template: ['<p>Enter color: <input type="text" ng-model="colour"></p>', '<input type="button" ng-click="func()" value="ChangeColorDirective" />'
        ].join('')
    }

})
app.controller('myController', function ($scope) {
    $scope.colour = '#34495e';
    $scope.myColor = { 'background-image': 'url("loading.gif")','background-repeat': 'no-repeat','background-size':'auto'};
    $scope.chngColor = function () {
       // $scope.myColor = { background: $scope.colour };
        $scope.myColor = { 'background-image': 'url("source.gif")', 'background-repeat': 'no-repeat', 'background-size': 'auto' };
    }
})
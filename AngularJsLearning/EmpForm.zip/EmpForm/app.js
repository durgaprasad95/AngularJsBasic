﻿var app = angular.module('myApp', []);

app.controller('EmpController', ['$scope', '$rootScope', function ($scope, $rootScope) {

    $scope.appTitle = "Employee Form"
    $scope.Employees = [];

    $scope.empInfo = {
        id: '',
        name: '',
        job: '',
        salary: ''
    }

    $scope.addEmp = function (empInfo) {
        $scope.Employees.push({ id: empInfo.id, name: empInfo.name, job: empInfo.job, salary: empInfo.salary });
    }

    $scope.removeItem = function (index) {
        $scope.Employees.splice(index, 1);
    }
}]);